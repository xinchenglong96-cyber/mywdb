"use client"

import { useState, useEffect } from "react"
import { supabase } from "@/lib/supabase"
import { Avatar, AvatarFallback } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Home, Compass, Bell, User, PenSquare, Image as ImageIcon, Video, Trash2, Pencil, X, Loader2 } from "lucide-react"
import Link from "next/link"

type FeedbackItem = {
  id: string;
  type: string;
  user_id: string;
  content: string;
  created_at: string;
  users?: { nickname: string };
}

type LogItem = {
  id: string;
  project_id: string;
  user_id: string;
  content: string;
  media_type?: string;
  media_url?: string;
  likes: number;
  bg_color: string;
  created_at: string;
  users?: { nickname: string };
  projects?: { title: string };
  feedbacks: FeedbackItem[];
};

const MediaCarousel = ({ urls, isVideo }: { urls: string[], isVideo: boolean }) => {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [touchStart, setTouchStart] = useState<number | null>(null);
  const [touchEnd, setTouchEnd] = useState<number | null>(null);

  const minSwipeDistance = 50;

  const nextSlide = () => setCurrentIndex(prev => (prev === urls.length - 1 ? prev : prev + 1));
  const prevSlide = () => setCurrentIndex(prev => (prev === 0 ? 0 : prev - 1));

  const onTouchStart = (e: React.TouchEvent | React.MouseEvent) => {
    setTouchEnd(null);
    if ('targetTouches' in e) {
      setTouchStart(e.targetTouches[0].clientX);
    } else {
      setTouchStart((e as React.MouseEvent).clientX);
    }
  };

  const onTouchMove = (e: React.TouchEvent | React.MouseEvent) => {
    if (!touchStart) return;
    if ('targetTouches' in e) {
      setTouchEnd(e.targetTouches[0].clientX);
    } else {
      setTouchEnd((e as React.MouseEvent).clientX);
    }
  };

  const onTouchEnd = () => {
    if (!touchStart || !touchEnd) return;
    const distance = touchStart - touchEnd;
    const isLeftSwipe = distance > minSwipeDistance;
    const isRightSwipe = distance < -minSwipeDistance;

    if (isLeftSwipe) {
      nextSlide();
    } else if (isRightSwipe) {
      prevSlide();
    }
    setTouchStart(null);
    setTouchEnd(null);
  };

  if (urls.length <= 1) {
    return (
      <div className="w-full border-2 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] bg-black overflow-hidden flex items-center justify-center relative mt-4 min-h-[300px]">
        {isVideo || urls[0]?.match(/\.(mp4|webm|ogg)/i) ? (
          <video src={urls[0]} controls className="w-full h-auto max-h-[600px] object-cover" />
        ) : (
          // eslint-disable-next-line @next/next/no-img-element
          <img src={urls[0]} alt="media-0" className="w-full h-auto max-h-[600px] object-cover mx-auto bg-white" />
        )}
      </div>
    );
  }

  return (
    <div 
      className="w-full border-2 border-black shadow-[6px_6px_0px_0px_rgba(0,0,0,1)] bg-black overflow-hidden relative mt-4 group cursor-grab active:cursor-grabbing"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
      onMouseDown={onTouchStart}
      onMouseMove={onTouchMove}
      onMouseUp={onTouchEnd}
      onMouseLeave={onTouchEnd}
    >
      <div 
        className="flex transition-transform duration-300 ease-in-out w-full"
        style={{ transform: `translateX(-${currentIndex * 100}%)` }}
      >
        {urls.map((url, i) => {
          const isVid = isVideo || url.match(/\.(mp4|webm|ogg)/i);
          return (
            <div key={i} className={`min-w-full flex-shrink-0 flex items-center justify-center bg-black min-h-[300px] ${isVid ? '' : 'pointer-events-none'}`}>
              {isVid ? (
                <video src={url} controls className="w-full h-auto max-h-[600px] object-cover pointer-events-auto" />
              ) : (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={url} alt={`media-${i}`} className="w-full h-auto max-h-[600px] object-cover mx-auto bg-white select-none pointer-events-none" draggable={false} />
              )}
            </div>
          );
        })}
      </div>

      <button 
        onClick={(e) => { e.stopPropagation(); prevSlide(); }}
        className={`absolute left-2 top-1/2 -translate-y-1/2 bg-white/90 p-2 sm:p-3 text-black border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] opacity-0 group-hover:opacity-100 transition-opacity active:translate-x-[2px] active:translate-y-[2px] active:shadow-none font-black text-xl z-20 ${currentIndex === 0 ? 'hidden' : ''}`}
      >
        {"<"}
      </button>
      <button 
        onClick={(e) => { e.stopPropagation(); nextSlide(); }}
        className={`absolute right-2 top-1/2 -translate-y-1/2 bg-white/90 p-2 sm:p-3 text-black border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] opacity-0 group-hover:opacity-100 transition-opacity active:translate-x-[2px] active:translate-y-[2px] active:shadow-none font-black text-xl z-20 ${currentIndex === urls.length - 1 ? 'hidden' : ''}`}
      >
        {">"}
      </button>
      
      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 flex gap-3 bg-black/50 px-3 py-2 rounded-full border-2 border-black backdrop-blur-sm z-10 pointer-events-none">
        {urls.map((_, i) => (
          <div key={i} className={`w-3 h-3 rounded-full border-2 border-black transition-colors ${i === currentIndex ? 'bg-yellow-400' : 'bg-white'}`} />
        ))}
      </div>
    </div>
  );
};

export default function FeedPage() {
  const [logs, setLogs] = useState<LogItem[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [myUserId, setMyUserId] = useState<string | null>(null);
  const [sessionUser, setSessionUser] = useState<any>(null); // { nickname, avatar_url, email }

  const [newProject, setNewProject] = useState("")
  const [newContent, setNewContent] = useState("")

  const [activeFeedbackLogId, setActiveFeedbackLogId] = useState<string | null>(null);
  const [activeFeedbackType, setActiveFeedbackType] = useState<string>("");
  const [feedbackText, setFeedbackText] = useState("");

  const [logToDelete, setLogToDelete] = useState<string | null>(null);
  const [feedbackToDelete, setFeedbackToDelete] = useState<{logId: string, feedbackId: string} | null>(null);
  const [alertMessage, setAlertMessage] = useState<string | null>(null);

  // 다중 미디어 업로드 상태
  const [selectedFiles, setSelectedFiles] = useState<File[]>([]);
  const [filePreviews, setFilePreviews] = useState<string[]>([]);
  const [currentMediaType, setCurrentMediaType] = useState<'image' | 'video' | null>(null);
  const [isUploading, setIsUploading] = useState(false);

  // 수정 (Edit) 상태
  const [editingLogId, setEditingLogId] = useState<string | null>(null);
  const [editLogContent, setEditLogContent] = useState("");
  const [editExistingUrls, setEditExistingUrls] = useState<string[]>([]);
  const [editNewFiles, setEditNewFiles] = useState<File[]>([]);
  const [editNewPreviews, setEditNewPreviews] = useState<string[]>([]);
  const [editMediaType, setEditMediaType] = useState<'image' | 'video' | null>(null);

  const [editingFeedbackId, setEditingFeedbackId] = useState<string | null>(null);
  const [editFeedbackContent, setEditFeedbackContent] = useState("");

  useEffect(() => {
    const fetchUserProfile = async (uid: string, sessionMeta: any, sessionEmail: string) => {
      const { data } = await supabase.from('users').select('*').eq('id', uid).single();
      if (data) {
        setSessionUser({
          nickname: data.nickname,
          avatar_url: sessionMeta?.avatar_url || null
        });
      } else {
        // SQL 트리거가 없거나 실패해서 DB 테이블에 이 유저가 없을 경우 자가 치유(Self-Healing)
        const fallbackNickname = sessionMeta?.full_name || sessionMeta?.name || '구글 접속자';
        setSessionUser({
          nickname: fallbackNickname,
          avatar_url: sessionMeta?.avatar_url || null
        });
        
        // 프론트엔드 코드가 권한을 갖고 직접 DB에 인서트 해버림!
        await supabase.from('users').upsert({
          id: uid,
          nickname: fallbackNickname,
          email: sessionEmail
        });
      }
    };

    const initAuth = async () => {
      const searchParams = new URLSearchParams(window.location.search);
      const hashParams = new URLSearchParams(window.location.hash.substring(1));
      const urlError = searchParams.get('error_description') || hashParams.get('error_description');
      
      if (urlError) {
        let msg = decodeURIComponent(urlError.replace(/\+/g, ' '));
        if (msg.includes('sending') || msg.includes('email')) {
          msg = "현재 Supabase 기본 이메일 서버 전송 한도가 초과되었거나 오류가 발생했습니다.\n\n[해결 방법]\nSupabase 대시보드 👉 Authentication 👉 Providers 👉 Email 메뉴에서\n'Confirm email' 과 'Send welcome email' 옵션을 OFF(끄기)로 설정하고 저장한 뒤 구글 로그인을 다시 시도해주세요!";
        }
        setAlertMessage(`⚠️ 구글 연동 중 오류 발생\n\n${msg}`);
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      const { data: { session } } = await supabase.auth.getSession();
      
      if (session) {
        setMyUserId(session.user.id);
        fetchUserProfile(session.user.id, session.user.user_metadata, session.user.email || '');
      } else {
        setMyUserId(null);
        setSessionUser(null);
      }

      supabase.auth.onAuthStateChange(async (_event, session) => {
        if (session) {
          setMyUserId(session.user.id);
          fetchUserProfile(session.user.id, session.user.user_metadata, session.user.email || '');
        } else {
          setMyUserId(null);
          setSessionUser(null);
        }
      });

      fetchLogs();
    };

    initAuth();
  }, []);

  const fetchLogs = async () => {
    setIsLoading(true);
    const { data: logsData, error } = await supabase
      .from('logs')
      .select(`
        *,
        users ( nickname ),
        projects ( title ),
        feedbacks (
          id, type, content, created_at, user_id,
          users ( nickname )
        )
      `)
      .order('created_at', { ascending: false });

    if (error) {
      console.error("logs 불러오기 에러:", error);
    } else if (logsData) {
      setLogs(logsData as any);
    }
    setIsLoading(false);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    if (selectedFiles.length + files.length > 5) {
      setAlertMessage("업로드 부담을 줄이기 위해 한 번에 최대 5장까지만 올릴 수 있습니다.");
      return;
    }
    const newFiles = [...selectedFiles, ...files];
    setSelectedFiles(newFiles);
    setFilePreviews(newFiles.map(file => URL.createObjectURL(file)));
    setCurrentMediaType(type);
  };

  const handleCancelFile = (index: number) => {
    const newFiles = selectedFiles.filter((_, i) => i !== index);
    setSelectedFiles(newFiles);
    setFilePreviews(newFiles.map(file => URL.createObjectURL(file)));
    if (newFiles.length === 0) setCurrentMediaType(null);
  };

  const clearAllFiles = () => {
    setSelectedFiles([]);
    setFilePreviews([]);
    setCurrentMediaType(null);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!myUserId) {
      setAlertMessage("글을 작성하려면 먼저 구글 로그인을 진행해주세요!");
      return;
    }
    if (!newProject.trim() || !newContent.trim()) {
      setAlertMessage("프로젝트 이름과 작업 내용을 모두 입력해주세요!");
      return;
    }

    setIsUploading(true);
    let uploadedUrls: string[] = [];

    // 멀티 미디어 파일이 선택된 경우 Supabase Storage 연동
    if (selectedFiles.length > 0) {
      for (const file of selectedFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `uploads/${fileName}`;

        const { error: uploadError } = await supabase.storage
          .from('media')
          .upload(filePath, file);
        
        if (uploadError) {
          setIsUploading(false);
          console.error("Upload Error:", uploadError);
          setAlertMessage(`파일 첨부 실패!\n에러 메시지: ${uploadError.message}`);
          return;
        }

        const { data: publicUrlData } = supabase.storage.from('media').getPublicUrl(filePath);
        uploadedUrls.push(publicUrlData.publicUrl);
      }
    }

    // 프로젝트 확인 및 생성
    let projectId = null;
    const { data: existingProject } = await supabase
      .from('projects')
      .select('id')
      .eq('title', newProject)
      .eq('user_id', myUserId)
      .single();

    if (existingProject) {
      projectId = existingProject.id;
    } else {
      const { data: createdProject, error } = await supabase
        .from('projects')
        .insert({ title: newProject, user_id: myUserId })
        .select().single();
      if (error) console.error("프로젝트 생성 에러:", error);
      if (createdProject) projectId = createdProject.id;
    }

    if (!projectId) {
      setIsUploading(false);
      return;
    }

    // 작업 로그 (Post) 생성
    const { data: newLog, error } = await supabase
      .from('logs')
      .insert({
        project_id: projectId,
        user_id: myUserId,
        content: newContent,
        media_type: currentMediaType,
        media_url: uploadedUrls.length > 0 ? JSON.stringify(uploadedUrls) : null,
        bg_color: ['bg-green-300', 'bg-blue-300', 'bg-yellow-300', 'bg-pink-300'][Math.floor(Math.random() * 4)]
      })
      .select(`
        *,
        users ( nickname ),
        projects ( title ),
        feedbacks ( * )
      `)
      .single();

    setIsUploading(false);

    if (error) {
      console.error("로그 생성 에러:", error);
      setAlertMessage("업로드 중 오류가 발생했습니다.");
    } else if (newLog) {
      newLog.feedbacks = newLog.feedbacks || [];
      setLogs([newLog as any, ...logs]);
      setNewProject('');
      setNewContent('');
      clearAllFiles();
    }
  }

  // 삭제 & 수정 (로그)
  const confirmDeleteLog = (logId: string) => setLogToDelete(logId);
  const executeDeleteLog = async () => {
    if (!logToDelete) return;
    const { error } = await supabase.from('logs').delete().eq('id', logToDelete).eq('user_id', myUserId);
    if (!error) {
      setLogs(logs.filter(log => log.id !== logToDelete));
    } else {
      setAlertMessage("로그 삭제 중 오류가 발생했습니다.");
    }
    setLogToDelete(null);
  };

  const startEditLog = (logId: string, currentContent: string, mediaUrlStr: string | null | undefined, mType: string | null | undefined) => {
    setEditingLogId(logId);
    setEditLogContent(currentContent);
    let urls: string[] = [];
    try {
      if (mediaUrlStr?.startsWith('[')) urls = JSON.parse(mediaUrlStr);
      else if (mediaUrlStr) urls = [mediaUrlStr];
    } catch {
      if (mediaUrlStr) urls = [mediaUrlStr];
    }
    setEditExistingUrls(urls);
    setEditNewFiles([]);
    setEditNewPreviews([]);
    setEditMediaType((mType as any) || null);
  };

  const cancelEditLog = () => {
    setEditingLogId(null);
    setEditLogContent("");
    setEditExistingUrls([]);
    setEditNewFiles([]);
    setEditNewPreviews([]);
    setEditMediaType(null);
  };

  const handleEditFileSelect = (e: React.ChangeEvent<HTMLInputElement>, type: 'image' | 'video') => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;
    if (editExistingUrls.length + editNewFiles.length + files.length > 5) {
      setAlertMessage("미디어는 최대 5장까지만 유지/추가할 수 있습니다.");
      return;
    }
    const newFs = [...editNewFiles, ...files];
    setEditNewFiles(newFs);
    setEditNewPreviews(newFs.map(f => URL.createObjectURL(f)));
    if (!editMediaType) setEditMediaType(type);
  };

  const handleCancelEditNewFile = (index: number) => {
    const newFs = editNewFiles.filter((_, i) => i !== index);
    setEditNewFiles(newFs);
    setEditNewPreviews(newFs.map(f => URL.createObjectURL(f)));
  };

  const handleRemoveExistingUrl = (index: number) => {
    setEditExistingUrls(prev => prev.filter((_, i) => i !== index));
  };

  const saveEditLog = async (logId: string) => {
    if (!editLogContent.trim()) return;
    setIsUploading(true);

    let uploadedUrls: string[] = [];
    if (editNewFiles.length > 0) {
      for (const file of editNewFiles) {
        const fileExt = file.name.split('.').pop();
        const fileName = `${Date.now()}_${Math.random().toString(36).substring(7)}.${fileExt}`;
        const filePath = `uploads/${fileName}`;
        const { error: uploadError } = await supabase.storage.from('media').upload(filePath, file);
        if (uploadError) {
          setIsUploading(false);
          setAlertMessage(`파일 첨부 실패!\n에러 메시지: ${uploadError.message}`);
          return;
        }
        const { data: publicUrlData } = supabase.storage.from('media').getPublicUrl(filePath);
        uploadedUrls.push(publicUrlData.publicUrl);
      }
    }

    const finalUrls = [...editExistingUrls, ...uploadedUrls];
    let finalMediaType = editMediaType;
    if (finalUrls.length === 0) finalMediaType = null;

    const { error } = await supabase.from('logs').update({ 
      content: editLogContent,
      media_url: finalUrls.length > 0 ? JSON.stringify(finalUrls) : null,
      media_type: finalMediaType
    }).eq('id', logId).eq('user_id', myUserId);
    
    setIsUploading(false);

    if (!error) {
      setLogs(logs.map(log => log.id === logId ? { 
        ...log, 
        content: editLogContent,
        media_url: finalUrls.length > 0 ? JSON.stringify(finalUrls) : undefined,
        media_type: finalMediaType || undefined
      } : log));
      cancelEditLog();
    } else {
      setAlertMessage("로그 수정 중 오류가 발생했습니다.");
    }
  };

  // 삭제 & 수정 (피드백)
  const confirmDeleteFeedback = (logId: string, feedbackId: string) => setFeedbackToDelete({logId, feedbackId});
  const executeDeleteFeedback = async () => {
    if (!feedbackToDelete) return;
    const { error } = await supabase.from('feedbacks').delete().eq('id', feedbackToDelete.feedbackId).eq('user_id', myUserId);
    if (!error) {
      setLogs(logs.map(log => {
        if (log.id === feedbackToDelete.logId) {
          return { ...log, feedbacks: log.feedbacks.filter(fb => fb.id !== feedbackToDelete.feedbackId) };
        }
        return log;
      }));
    } else {
      setAlertMessage("피드백 삭제 중 오류가 발생했습니다.");
    }
    setFeedbackToDelete(null);
  };

  const startEditFeedback = (feedbackId: string, currentContent: string) => {
    setEditingFeedbackId(feedbackId);
    setEditFeedbackContent(currentContent);
  };
  const cancelEditFeedback = () => {
    setEditingFeedbackId(null);
    setEditFeedbackContent("");
  };
  const saveEditFeedback = async (logId: string, feedbackId: string) => {
    if (!editFeedbackContent.trim()) return;
    const { error } = await supabase.from('feedbacks').update({ content: editFeedbackContent }).eq('id', feedbackId).eq('user_id', myUserId);
    if (!error) {
      setLogs(logs.map(log => {
        if (log.id === logId) {
          return {
            ...log,
            feedbacks: log.feedbacks.map(fb => fb.id === feedbackId ? { ...fb, content: editFeedbackContent } : fb)
          };
        }
        return log;
      }));
      setEditingFeedbackId(null);
    } else {
      setAlertMessage("피드백 수정 중 오류가 발생했습니다.");
    }
  };

  const handleFeedbackClick = (logId: string, type: string) => {
    if (activeFeedbackLogId === logId && activeFeedbackType === type) {
      setActiveFeedbackLogId(null);
      setActiveFeedbackType("");
      return;
    }
    setActiveFeedbackLogId(logId);
    setActiveFeedbackType(type);
    setFeedbackText("");
  }

  const handleFeedbackSubmit = async (e: React.FormEvent, logId: string) => {
    e.preventDefault();
    if (!myUserId) {
      setAlertMessage("피드백을 남기시려면 로그인이 필요합니다.");
      return;
    }
    if (!feedbackText.trim()) return;

    const { data: newFeedback, error } = await supabase
      .from('feedbacks')
      .insert({ log_id: logId, user_id: myUserId, type: activeFeedbackType, content: feedbackText })
      .select(`*, users ( nickname )`)
      .single();

    if (error) {
      setAlertMessage("피드백 등록 중 오류가 발생했습니다.");
    } else if (newFeedback) {
      setLogs(logs.map(log => 
        log.id === logId 
          ? { ...log, feedbacks: [...(log.feedbacks || []), newFeedback as any] } 
          : log
      ));
      setActiveFeedbackLogId(null);
      setActiveFeedbackType("");
      setFeedbackText("");
    }
  }

  const timeAgo = (dateStr: string) => {
    const diff = Date.now() - new Date(dateStr).getTime();
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return '방금 전';
    if (minutes < 60) return `${minutes}분 전`;
    if (minutes < 1440) return `${Math.floor(minutes / 60)}시간 전`;
    return dateStr.slice(0, 10);
  }

  // Custom brutalist classes
  const brutalShadow = "shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]"
  const brutalActive = "active:shadow-none active:translate-x-[4px] active:translate-y-[4px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all"
  const brutalBorder = "border-2 border-black !rounded-none"
  const cardShadow = "shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]"
  const cardBorder = "border-4 border-black !rounded-none"

  return (
    <div className="flex min-h-screen bg-pink-50 font-sans text-black relative">
      {/* Sidebar Navigation */}
      <aside className={`fixed hidden w-64 flex-col bg-green-200 px-4 py-8 sm:flex h-full ${cardBorder} border-y-0 border-l-0 border-r-4 z-10`}>
        <div className="mb-8 px-4">
          <h1 className="text-3xl font-black uppercase tracking-tighter shadow-black drop-shadow-[2px_2px_0px_rgba(0,0,0,1)] text-white">WorkLog</h1>
        </div>
        <nav className="flex flex-1 flex-col gap-4 mt-8">
          <Button variant="outline" className={`justify-start gap-3 px-4 font-bold text-lg bg-yellow-300 ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
            <Home className="h-6 w-6 stroke-[3px]" /> 피드
          </Button>
          <Button variant="outline" className={`justify-start gap-3 px-4 font-bold text-lg bg-white ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
            <Compass className="h-6 w-6 stroke-[3px]" /> 탐색
          </Button>
          <Button variant="outline" className={`justify-start gap-3 px-4 font-bold text-lg bg-white ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
            <Bell className="h-6 w-6 stroke-[3px]" /> 알림
          </Button>
          {!myUserId && (
            <Button asChild variant="outline" className={`justify-start gap-3 px-4 font-bold text-lg bg-cyan-300 hover:bg-cyan-400 ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
              <Link href="/login">
                <User className="h-6 w-6 stroke-[3px]" /> 로그인하기
              </Link>
            </Button>
          )}
        </nav>
        
        {/* User Profile Block */}
        <div className="mt-auto pt-4 border-t-4 border-black border-dashed">
          {sessionUser ? (
            <>
              <div className="flex items-center gap-3 px-2 py-4 mb-4">
                <Avatar className={`h-12 w-12 ${brutalBorder}`}>
                  {sessionUser.avatar_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={sessionUser.avatar_url} alt="profile" className="w-full h-full object-cover" />
                  ) : (
                    <AvatarFallback className="bg-orange-400 font-bold text-black border-2 border-black">
                      {sessionUser.nickname ? sessionUser.nickname.slice(0, 1) : '?'}
                    </AvatarFallback>
                  )}
                </Avatar>
                <div className="flex flex-col flex-1 overflow-hidden">
                  <span className="text-sm font-black uppercase truncate">{sessionUser.nickname}</span>
                  <button onClick={() => supabase.auth.signOut()} className="text-xs font-bold text-slate-800 text-left hover:text-blue-600 underline decoration-2 mt-1">로그아웃</button>
                </div>
              </div>
              <Button onClick={() => window.scrollTo({top: 0, behavior: 'smooth'})} className={`w-full gap-2 font-black text-lg py-6 bg-red-400 text-black hover:bg-red-500 hover:text-black ${brutalBorder} ${brutalShadow} ${brutalActive}`} size="lg">
                <PenSquare className="h-6 w-6 stroke-[3]" /> 새 작업 기록
              </Button>
            </>
          ) : (
            <div className="py-2">
              <p className="text-base font-bold text-black mb-4">가입하고 나만의 로그를 기록하세요!</p>
              <Button asChild className={`w-full gap-2 font-black text-lg py-6 bg-white text-black hover:bg-slate-100 ${brutalBorder} ${brutalShadow} ${brutalActive}`} size="lg">
                <Link href="/login">🚀 구글로 시작하기</Link>
              </Button>
            </div>
          )}
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 sm:ml-64 bg-slate-50 min-h-screen">
        <div className="mx-auto max-w-2xl px-4 py-12 sm:px-6 lg:px-8">
          <header className="mb-12">
            <h2 className="text-4xl font-black uppercase tracking-tight text-white drop-shadow-[2px_2px_0px_rgba(0,0,0,1)] bg-black inline-block px-4 py-2 border-4 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)]">
              FEED
            </h2>
            <p className="text-md font-bold text-black mt-4 ml-6 bg-yellow-300 inline-block px-3 py-1 border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
              치열한 고민의 흔적을 첨부자료와 함께 소통하세요.
            </p>
          </header>

          {/* Create Log Input Form */}
          <Card className={`mb-12 bg-white ${cardBorder} ${cardShadow}`}>
            <form onSubmit={handleSubmit}>
              <CardContent className="pt-6">
                <div className="flex gap-4">
                  <Avatar className={`mt-1 h-12 w-12 ${brutalBorder} ${!myUserId ? 'opacity-50' : ''}`}>
                  {sessionUser?.avatar_url ? (
                    // eslint-disable-next-line @next/next/no-img-element
                    <img src={sessionUser.avatar_url} alt="profile" className="w-full h-full object-cover" />
                  ) : (
                    <AvatarFallback className="bg-cyan-300 font-bold text-black border-2 border-black">
                      {sessionUser?.nickname ? sessionUser.nickname.slice(0, 1) : '?'}
                    </AvatarFallback>
                  )}
                  </Avatar>
                  <div className="flex-1 space-y-4">
                    <Input 
                      value={newProject}
                      onChange={(e) => setNewProject(e.target.value)}
                      placeholder={myUserId ? "어떤 프로젝트를 작업 중이신가요?" : "🔥 참여하려면 먼저 로그인해주세요!"} 
                      className={`bg-white px-3 py-6 text-lg font-bold placeholder:text-neutral-500 ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] focus-visible:ring-0 focus-visible:shadow-none focus-visible:translate-x-[4px] focus-visible:translate-y-[4px] transition-all disabled:opacity-50`} 
                      disabled={isUploading || !myUserId}
                    />
                    <Textarea 
                      value={newContent}
                      onChange={(e) => setNewContent(e.target.value)}
                      placeholder={myUserId ? "오늘 수정한 부분, 막힌 에러, 새로운 시도를 공유하세요! 사진이나 영상 업로드도 실지원합니다." : "로그인 후 나만의 멋진 작업 과정을 남겨보세요."} 
                      className={`min-h-[120px] bg-white px-3 py-4 font-bold placeholder:text-neutral-500 resize-none ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] focus-visible:ring-0 focus-visible:shadow-none focus-visible:translate-x-[4px] focus-visible:translate-y-[4px] transition-all disabled:opacity-50`}
                      disabled={isUploading || !myUserId}
                    />

                    {/* Multi-Media Preview Box */}
                    {filePreviews.length > 0 && (
                      <div className={`relative w-full p-4 bg-slate-100 ${brutalBorder} ${brutalShadow}`}>
                        <p className="text-sm font-black mb-3 text-slate-800">첨부된 미디어 미리보기 ({filePreviews.length}/5)</p>
                        <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
                          {filePreviews.map((preview, i) => (
                            <div key={i} className={`relative flex-shrink-0 w-32 h-32 ${brutalBorder} snap-center`}>
                              <Button type="button" onClick={() => handleCancelFile(i)} variant="outline" size="icon" className={`absolute -top-3 -right-3 bg-red-400 hover:bg-red-500 text-black h-8 w-8 rounded-full border-2 border-black z-10 p-0 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all`} disabled={isUploading}>
                                <X className="h-5 w-5 stroke-[3]" />
                              </Button>
                              {currentMediaType === 'video' ? (
                                <video src={preview} className="w-full h-full object-cover bg-black" />
                              ) : (
                                // eslint-disable-next-line @next/next/no-img-element
                                <img src={preview} alt={'pre-'+i} className="w-full h-full object-cover" />
                              )}
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>

              {/* Hidden File Inputs */}
              {/* Hidden Multi-File Inputs */}
              <input type="file" id="image-upload" accept="image/*" multiple className="hidden" onChange={(e) => handleFileSelect(e, 'image')} />
              <input type="file" id="video-upload" accept="video/*" multiple className="hidden" onChange={(e) => handleFileSelect(e, 'video')} />

              <CardFooter className="justify-between border-t-4 border-black bg-cyan-200 px-6 py-4">
                <div className="flex gap-4 text-black font-bold">
                  <Button type="button" onClick={() => myUserId && document.getElementById('image-upload')?.click()} variant="outline" className={`bg-white gap-2 font-black ${brutalBorder} ${brutalShadow} ${brutalActive}`} disabled={isUploading || !myUserId}>
                    <ImageIcon className="h-5 w-5 stroke-[2]" /> 이미지
                  </Button>
                  <Button type="button" onClick={() => myUserId && document.getElementById('video-upload')?.click()} variant="outline" className={`bg-white gap-2 font-black ${brutalBorder} ${brutalShadow} ${brutalActive}`} disabled={isUploading || !myUserId}>
                    <Video className="h-5 w-5 stroke-[2]" /> 비디오
                  </Button>
                </div>
                {!myUserId ? (
                  <Button asChild type="button" className={`bg-black text-white px-8 font-bold text-lg min-w-[120px] ${brutalBorder} hover:bg-slate-800 hover:text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all`}>
                    <Link href="/login">구글 로그인</Link>
                  </Button>
                ) : (
                  <Button type="submit" className={`bg-black text-white px-8 font-bold text-lg flex items-center justify-center min-w-[120px] ${brutalBorder} hover:bg-slate-800 hover:text-white shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all`} disabled={isUploading}>
                    {isUploading ? <Loader2 className="animate-spin h-6 w-6 stroke-[3]" /> : '업로드'}
                  </Button>
                )}
              </CardFooter>
            </form>
          </Card>

          {/* Feed Logs */}
          <div className="space-y-12 mb-20">
            {logs.length === 0 && !isLoading && (
              <div className="text-center bg-white border-4 border-black p-8 shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]">
                <p className="text-2xl font-black">아직 등록된 작업 로그가 없습니다.</p>
                <p className="text-lg font-bold mt-2">상단의 폼을 통해 첫 로그를 남겨보세요!</p>
              </div>
            )}
            {logs.map(log => (
              <Card key={log.id} className={`${log.bg_color || 'bg-white'} ${cardBorder} ${cardShadow}`}>
                <CardHeader className="pb-4">
                  <div className="flex items-start justify-between w-full">
                    <div className="flex items-start gap-4 w-full">
                      <Avatar className={`h-14 w-14 mt-1 ${brutalBorder}`}>
                        <AvatarFallback className="bg-white font-black text-3xl text-black border-2 border-black">
                          {log.users?.nickname ? log.users.nickname.slice(0, 1) : '?'}
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex flex-col gap-2 w-full">
                        <span className="bg-white inline-block px-3 py-1 border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] text-2xl sm:text-3xl font-black uppercase max-w-fit leading-tight break-all border-b-[6px]">
                          {log.projects?.title || 'Unknown'}
                        </span>
                        <div className="flex flex-wrap items-center gap-2 text-base font-bold text-slate-800">
                          <span className="underline decoration-2 underline-offset-2 break-all">{log.users?.nickname || 'Unknown'}</span>
                          <span className="font-extrabold">•</span>
                          <span>{timeAgo(log.created_at)}</span>
                        </div>
                      </div>
                    </div>
                    {myUserId && log.user_id === myUserId && (
                      <div className="flex gap-2">
                        <Button onClick={() => startEditLog(log.id, log.content, log.media_url, log.media_type)} variant="outline" size="icon" className={`bg-blue-300 hover:bg-blue-400 text-black border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all`}>
                          <Pencil className="h-5 w-5 stroke-[2]" />
                        </Button>
                        <Button onClick={() => confirmDeleteLog(log.id)} variant="outline" size="icon" className={`bg-red-400 hover:bg-red-500 text-black border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[2px] active:translate-y-[2px] transition-all`}>
                          <Trash2 className="h-5 w-5 stroke-[3]" />
                        </Button>
                      </div>
                    )}
                  </div>
                </CardHeader>
                <CardContent>
                  <div className={`bg-white p-4 ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex flex-col gap-4`}>
                    
                    {/* Log Content or Editor */}
                    {editingLogId === log.id ? (
                      <div className="flex flex-col gap-3">
                        <Textarea 
                          value={editLogContent} 
                          onChange={(e) => setEditLogContent(e.target.value)} 
                          className={`min-h-[100px] bg-yellow-50 font-bold resize-none ${brutalBorder} focus-visible:ring-0 shadow-inner p-3`}
                        />
                        
                        {/* 편집 모드: 기존 및 새 첨부파일 관리 */}
                        <div className={`w-full p-4 bg-slate-100 ${brutalBorder}`}>
                          <p className="text-sm font-black mb-3 text-slate-800">미디어 편집 (최대 5장)</p>
                          <div className="flex gap-4 overflow-x-auto pb-4 snap-x">
                            {/* 기존 미디어 */}
                            {editExistingUrls.map((url, i) => (
                              <div key={`ex-${i}`} className={`relative flex-shrink-0 w-24 h-24 ${brutalBorder} snap-center`}>
                                <Button type="button" onClick={() => handleRemoveExistingUrl(i)} variant="outline" size="icon" className={`absolute -top-3 -right-3 bg-red-400 hover:bg-red-500 text-black h-6 w-6 rounded-full border-2 border-black z-10 p-0 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[1px] active:translate-y-[1px] transition-all`} disabled={isUploading}>
                                  <X className="h-4 w-4 stroke-[3]" />
                                </Button>
                                {url.match(/\.(mp4|webm|ogg)/i) || editMediaType === 'video' ? (
                                  <video src={url} className="w-full h-full object-cover bg-black" />
                                ) : (
                                  // eslint-disable-next-line @next/next/no-img-element
                                  <img src={url} alt={'ex-'+i} className="w-full h-full object-cover" />
                                )}
                              </div>
                            ))}
                            {/* 새 미디어 추가본 */}
                            {editNewPreviews.map((preview, i) => (
                              <div key={`new-${i}`} className={`relative flex-shrink-0 w-24 h-24 border-2 border-dashed border-blue-500 snap-center bg-white`}>
                                <Button type="button" onClick={() => handleCancelEditNewFile(i)} variant="outline" size="icon" className={`absolute -top-3 -right-3 bg-red-400 hover:bg-red-500 text-black h-6 w-6 rounded-full border-2 border-black z-10 p-0 shadow-[1px_1px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[1px] active:translate-y-[1px] transition-all`} disabled={isUploading}>
                                  <X className="h-4 w-4 stroke-[3]" />
                                </Button>
                                {editMediaType === 'video' ? (
                                  <video src={preview} className="w-full h-full object-cover bg-black opacity-80" />
                                ) : (
                                  // eslint-disable-next-line @next/next/no-img-element
                                  <img src={preview} alt={'pre-'+i} className="w-full h-full object-cover opacity-80" />
                                )}
                              </div>
                            ))}
                          </div>
                          
                          <div className="flex gap-2 mt-2">
                            <input type="file" id={`edit-image-${log.id}`} accept="image/*" multiple className="hidden" onChange={(e) => handleEditFileSelect(e, 'image')} />
                            <input type="file" id={`edit-video-${log.id}`} accept="video/*" multiple className="hidden" onChange={(e) => handleEditFileSelect(e, 'video')} />
                            <Button type="button" onClick={() => document.getElementById(`edit-image-${log.id}`)?.click()} variant="outline" size="sm" className={`bg-white font-black text-xs ${brutalBorder} shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`} disabled={isUploading}>+ 사진 추가</Button>
                            <Button type="button" onClick={() => document.getElementById(`edit-video-${log.id}`)?.click()} variant="outline" size="sm" className={`bg-white font-black text-xs ${brutalBorder} shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`} disabled={isUploading}>+ 영상 추가</Button>
                          </div>
                        </div>

                        <div className="flex justify-end gap-2 mt-2">
                          <Button onClick={cancelEditLog} variant="outline" className={`bg-white font-black ${brutalBorder} ${brutalShadow} active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all`}>취소</Button>
                          <Button onClick={() => saveEditLog(log.id)} className={`bg-blue-500 text-white font-black border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] hover:bg-blue-600 active:translate-x-[2px] active:translate-y-[2px] active:shadow-none transition-all`} disabled={isUploading}>
                            {isUploading ? <Loader2 className="animate-spin h-5 w-5 mr-2" /> : null} 저장
                          </Button>
                        </div>
                      </div>
                    ) : (
                      <>
                        <p className="whitespace-pre-wrap text-base font-bold leading-relaxed text-black">{log.content}</p>
                        {/* Carousel Render */}
                        {(() => {
                          if (!log.media_url) return null;
                          let urls: string[] = [];
                          try {
                            if (log.media_url.startsWith('[')) urls = JSON.parse(log.media_url);
                            else urls = [log.media_url];
                          } catch {
                            urls = [log.media_url];
                          }
                          if (urls.length === 0) return null;
                          const isVideo = log.media_type === 'video';
                          
                          return <MediaCarousel urls={urls} isVideo={isVideo} />;
                        })()}
                      </>
                    )}
                  </div>
                </CardContent>

                {/* Feedback Selection Footer */}
                <CardFooter className="border-t-4 border-black pt-4 pb-4 bg-white/70 backdrop-blur-sm mt-4 flex-col gap-3 items-start">
                  <div className="w-full flex items-center gap-2 mb-2">
                    <span className="font-black bg-black text-white px-2 py-1 text-sm shadow-[2px_2px_0px_0px_rgba(255,255,255,1)]">선택형 피드백</span>
                    <span className="text-xs font-bold text-slate-500 bg-slate-100 px-2 py-1 border border-black">총 {log.feedbacks?.length || 0}개의 피드백</span>
                  </div>
                  <div className="flex flex-wrap gap-4 w-full">
                    <Button onClick={() => handleFeedbackClick(log.id, '💡 아이디어 제안')} variant="outline" className={`flex-1 gap-2 border-2 border-black !rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all font-black text-base ${activeFeedbackLogId === log.id && activeFeedbackType === '💡 아이디어 제안' ? 'bg-blue-400 text-white' : 'bg-blue-200 text-black hover:bg-blue-300'} py-6`}>
                      💡 아이디어 제안
                    </Button>
                    <Button onClick={() => handleFeedbackClick(log.id, '🛠️ 해결책 조언')} variant="outline" className={`flex-1 gap-2 border-2 border-black !rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all font-black text-base ${activeFeedbackLogId === log.id && activeFeedbackType === '🛠️ 해결책 조 조언' ? 'bg-red-500 text-white' : 'bg-red-300 text-black hover:bg-red-400'} py-6`}>
                      🛠️ 해결책 조언
                    </Button>
                    <Button onClick={() => handleFeedbackClick(log.id, '🔥 킵고잉 응원')} variant="outline" className={`flex-1 gap-2 border-2 border-black !rounded-none shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] active:shadow-none active:translate-x-[4px] active:translate-y-[4px] hover:shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] hover:translate-x-[2px] hover:translate-y-[2px] transition-all font-black text-base ${activeFeedbackLogId === log.id && activeFeedbackType === '🔥 킵고잉 응원' ? 'bg-green-500 text-white' : 'bg-green-300 text-black hover:bg-green-400'} py-6`}>
                      🔥 킵고잉 응원
                    </Button>
                  </div>
                </CardFooter>

                {/* Feedback Input Section (Conditional) */}
                {activeFeedbackLogId === log.id && (
                  <div className="bg-slate-200 border-t-4 border-black p-4">
                    <form onSubmit={(e) => handleFeedbackSubmit(e, log.id)} className="flex flex-col sm:flex-row gap-3">
                      <div className="flex items-center gap-2 w-full">
                        <span className="font-black bg-white border-2 border-black px-3 py-2 flex items-center shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] whitespace-nowrap">
                          {activeFeedbackType}
                        </span>
                        <Input 
                          value={feedbackText}
                          onChange={(e) => setFeedbackText(e.target.value)}
                          placeholder={myUserId ? "구체적인 피드백이나 응원의 메시지를 남겨주세요." : "로그인 후 소통할 수 있습니다!"}
                          className={`bg-white border-2 border-black font-bold flex-1 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] focus-visible:translate-x-[4px] focus-visible:translate-y-[4px] focus-visible:shadow-none transition-all py-6 disabled:opacity-50`}
                          disabled={!myUserId}
                          autoFocus
                        />
                        {!myUserId ? (
                          <Button asChild type="button" className={`h-auto bg-black text-white px-6 py-4 font-bold border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all text-lg`}>
                            <Link href="/login">가입하기</Link>
                          </Button>
                        ) : (
                          <Button type="submit" className={`h-auto bg-black text-white px-8 py-4 font-bold border-2 border-black shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all text-lg`}>
                            게시
                          </Button>
                        )}
                      </div>
                    </form>
                  </div>
                )}

                {/* Feedbacks Display */}
                {log.feedbacks && log.feedbacks.length > 0 && (
                  <div className="bg-slate-100 border-t-4 border-black p-4 space-y-4">
                    {log.feedbacks.map(fb => (
                      <div key={fb.id} className="flex gap-3 items-start">
                        <span className="text-xl font-black bg-white px-2 py-2 border-2 border-black inline-block shadow-[2px_2px_0px_0px_rgba(0,0,0,1)] mt-1 whitespace-nowrap leading-none">
                          {fb.type.split(' ')[0]} {/* The emoji */}
                        </span>
                        <div className="bg-white border-2 border-black p-3 shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] flex-1 relative">
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-sm font-black text-black">{fb.users?.nickname || 'Unknown'} <span className="text-xs ml-2 bg-black text-white px-1 leading-none">{fb.type}</span></p>
                          </div>
                          
                          {myUserId && fb.user_id === myUserId && (
                            <div className="absolute top-2 right-2 flex gap-1 bg-white border border-black p-1 shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]">
                              <button onClick={() => startEditFeedback(fb.id, fb.content)} className="text-blue-500 hover:text-blue-700 transition-colors p-1" title="수정">
                                <Pencil className="h-4 w-4 stroke-[3]" />
                              </button>
                              <button onClick={() => confirmDeleteFeedback(log.id, fb.id)} className="text-red-500 hover:text-red-700 transition-colors p-1" title="삭제">
                                <Trash2 className="h-4 w-4 stroke-[3]" />
                              </button>
                            </div>
                          )}

                          {/* Feedback Content or Editor */}
                          {editingFeedbackId === fb.id ? (
                            <div className="mt-2 flex flex-col gap-2">
                              <Textarea 
                                value={editFeedbackContent} 
                                onChange={(e) => setEditFeedbackContent(e.target.value)} 
                                className={`min-h-[80px] bg-yellow-50 font-bold resize-none ${brutalBorder} focus-visible:ring-0 p-2 text-sm`}
                              />
                              <div className="flex justify-end gap-2">
                                <Button onClick={cancelEditFeedback} variant="outline" size="sm" className={`bg-white font-black text-xs ${brutalBorder} shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`}>취소</Button>
                                <Button onClick={() => saveEditFeedback(log.id, fb.id)} size="sm" className={`bg-black text-white font-black text-xs border-2 border-black shadow-[2px_2px_0px_0px_rgba(0,0,0,1)]`}>완료</Button>
                              </div>
                            </div>
                          ) : (
                            <p className="text-base font-bold text-slate-800 pr-[4rem]">{fb.content}</p>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

              </Card>
            ))}
          </div>

        </div>
      </main>

      {/* Delete Log Modal Overlay */}
      {logToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className={`bg-white p-8 max-w-sm w-full flex flex-col items-center text-center ${cardBorder} shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] animate-in zoom-in-95 duration-200`}>
            <div className="bg-red-400 p-4 rounded-full border-4 border-black mb-6">
              <Trash2 className="h-10 w-10 stroke-[3] text-black" />
            </div>
            <h3 className="text-2xl font-black mb-2 uppercase text-black">정말 삭제할까요?</h3>
            <p className="font-bold text-slate-700 mb-8 leading-tight">이 작업 기록은 영구적으로 지워지며,<br/>다시는 복구할 수 없습니다.</p>
            <div className="flex gap-4 w-full">
              <Button onClick={() => setLogToDelete(null)} variant="outline" className={`flex-1 py-6 bg-slate-200 font-black text-lg text-black ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
                돌아가기
              </Button>
              <Button onClick={executeDeleteLog} className={`flex-1 py-6 bg-red-500 hover:bg-red-600 text-white font-black text-lg ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all`}>
                삭제
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Delete Feedback Modal Overlay */}
      {feedbackToDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className={`bg-yellow-300 p-8 max-w-sm w-full flex flex-col items-center text-center ${cardBorder} shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] animate-in zoom-in-95 duration-200`}>
            <h3 className="text-2xl font-black mb-2 uppercase text-black">피드백 삭제</h3>
            <p className="font-bold text-slate-800 mb-8 leading-tight">작성하신 피드백을 영구 삭제하시겠습니까?</p>
            <div className="flex gap-4 w-full">
              <Button onClick={() => setFeedbackToDelete(null)} variant="outline" className={`flex-1 py-6 bg-white font-black text-lg text-black ${brutalBorder} ${brutalShadow} ${brutalActive}`}>
                취소
              </Button>
              <Button onClick={executeDeleteFeedback} className={`flex-1 py-6 bg-black hover:bg-slate-800 text-white font-black text-lg ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all`}>
                삭제
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Custom Alert Modal Overlay */}
      {alertMessage && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className={`bg-red-400 p-8 max-w-sm w-full flex flex-col items-center text-center ${cardBorder} shadow-[12px_12px_0px_0px_rgba(0,0,0,1)] animate-in zoom-in-95 duration-200`}>
            <h3 className="text-3xl font-black mb-4 uppercase text-black">알림</h3>
            <p className="font-bold text-black mb-8 leading-relaxed whitespace-pre-wrap">{alertMessage}</p>
            <Button onClick={() => setAlertMessage(null)} className={`w-full py-6 bg-black hover:bg-slate-800 text-white font-black text-xl ${brutalBorder} shadow-[4px_4px_0px_0px_rgba(0,0,0,0.5)] active:translate-x-[4px] active:translate-y-[4px] active:shadow-none transition-all`}>
              확인
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
